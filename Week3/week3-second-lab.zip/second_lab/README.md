# Environment setup
- Create the virtual env - `python3 -m venv env`
- Activate the virtual env - `source env/bin/activate`
- Install the requirements - `pip3 install -r requirements.txt`

  # Zip the lab folder
    - `zip -r week3-second-lab.zip second_lab/`